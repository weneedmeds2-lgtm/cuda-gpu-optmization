#!/usr/bin/env bash
# Build + run the HISTOGRAM pipeline benchmark, auto-detecting GPU compute capability.
# Usage:
#   ./run_histogram.sh                        # default sizes
#   ./run_histogram.sh 32768,262144,1048576   # custom sizes
set -e

SRC="histogram_benchmark.cu"
BIN="histogram_benchmark"
mkdir -p results

ARCH=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -n1 | tr -d '.')
if [ -z "$ARCH" ]; then
    echo "Could not auto-detect GPU arch, defaulting to sm_75"
    ARCH="75"
fi
echo "Building for sm_${ARCH}..."

nvcc -O3 -arch=sm_${ARCH} "$SRC" -o "$BIN"

TS=$(date +%Y-%m-%d_%H%M%S)
LOG="results/run_histogram_${TS}.log"

echo "Running (sizes: ${1:-default})..."
./"$BIN" "$1" | tee "$LOG"

echo ""
echo "Log saved to: $LOG"
echo "CSV/MD saved alongside it in results/"
