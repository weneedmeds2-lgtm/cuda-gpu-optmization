// ===============================================
// HISTOGRAM PIPELINE BENCHMARK
// Naive        : per-thread linear scan for min/max, atomicAdd to global bins
// SM-Optimized : shared-memory tree reduction for min/max, shared-mem private histogram
// Warp-Optimized: warp-shuffle reduction for min/max, shared-mem private histogram
//
// Each pipeline = (min/max range reduction) + (binning/histogram build).
// Stress-tests all three across a range of N, times each with CUDA events,
// verifies against a CPU reference, and prints a metrics table:
// Algo | Implementation | N | Time(ms) | Verified
// Also writes results/run_<timestamp>.{log,csv,md}
// ===============================================
#include <device_launch_parameters.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <climits>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cuda_runtime.h>

using namespace std;

#define CUDA_CHECK(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { \
        cerr << "CUDA error " << cudaGetErrorString(err) \
             << " at " << __FILE__ << ":" << __LINE__ << endl; \
        exit(1); \
    } \
} while (0)

// ===============================================
// Min/Max range kernels (unchanged from your source)
// ===============================================
__device__ int warpminmax(int val, bool ismax) {
    for (int offset = 16; offset > 0; offset /= 2) {
        int tmp = __shfl_down_sync(0xffffffff, val, offset);
        if (ismax) {
            if (tmp > val) val = tmp;
        }
        else {
            if (tmp < val) val = tmp;
        }
    }
    return val;
}

__global__ void rangenaive(int* input, int* blockmin, int* blockmax, int n) {
    int gid = threadIdx.x + blockIdx.x * blockDim.x;
    if (gid < n) {
        int val = input[gid];
        int start = blockIdx.x * blockDim.x;
        int end = start + blockDim.x;
        if (end > n) end = n;

        int currentmin = val;
        int currentmax = val;
        for (int i = start; i < end; ++i) {
            int comp = input[i];
            if (comp < currentmin) currentmin = comp;
            if (comp > currentmax) currentmax = comp;
        }

        if (threadIdx.x == 0) {
            blockmin[blockIdx.x] = currentmin;
            blockmax[blockIdx.x] = currentmax;
        }
    }
}

__global__ void rangesharedmemory(int* input, int* blockmin, int* blockmax, int n) {
    extern __shared__ int smem[];
    int* minrange = smem;
    int* maxrange = smem + blockDim.x;
    int tid = threadIdx.x;
    int gid = threadIdx.x + blockIdx.x * blockDim.x;

    if (gid < n) {
        minrange[tid] = input[gid];
        maxrange[tid] = input[gid];
    }
    else {
        minrange[tid] = INT_MAX;
        maxrange[tid] = INT_MIN;
    }
    __syncthreads();

    for (int offset = blockDim.x / 2; offset > 0; offset /= 2) {
        if (tid < offset) {
            if (minrange[tid + offset] < minrange[tid]) {
                minrange[tid] = minrange[tid + offset];
            }
            if (maxrange[tid + offset] > maxrange[tid]) {
                maxrange[tid] = maxrange[tid + offset];
            }
        }
        __syncthreads();
    }

    if (tid == 0) {
        blockmin[blockIdx.x] = minrange[0];
        blockmax[blockIdx.x] = maxrange[0];
    }
}

__global__ void rangewarpoptimized(int* input, int* blockmin, int* blockmax, int n) {
    extern __shared__ int smem[];
    int* minshared = smem;
    int* maxshared = smem + (blockDim.x / 32);
    int tid = threadIdx.x;
    int gid = threadIdx.x + blockIdx.x * blockDim.x;
    int lane = tid % 32;
    int warpid = tid / 32;

    int valmin = INT_MAX;
    int valmax = INT_MIN;
    if (gid < n) {
        valmin = input[gid];
        valmax = input[gid];
    }

    valmin = warpminmax(valmin, false);
    valmax = warpminmax(valmax, true);

    if (lane == 0) {
        minshared[warpid] = valmin;
        maxshared[warpid] = valmax;
    }
    __syncthreads();

    if (warpid == 0) {
        int numwarps = blockDim.x / 32;
        int vmin = (tid < numwarps) ? minshared[tid] : INT_MAX;
        int vmax = (tid < numwarps) ? maxshared[tid] : INT_MIN;

        vmin = warpminmax(vmin, false);
        vmax = warpminmax(vmax, true);

        if (tid == 0) {
            blockmin[blockIdx.x] = vmin;
            blockmax[blockIdx.x] = vmax;
        }
    }
}

__global__ void globalrangereduce(int* blockmin, int* blockmax, int* outmin, int* outmax, int size) {
    extern __shared__ int smem[];
    int* minrange = smem;
    int* maxrange = smem + blockDim.x;
    int tid = threadIdx.x;
    int gid = threadIdx.x + blockIdx.x * blockDim.x;

    if (gid < size) {
        minrange[tid] = blockmin[gid];
        maxrange[tid] = blockmax[gid];
    }
    else {
        minrange[tid] = INT_MAX;
        maxrange[tid] = INT_MIN;
    }
    __syncthreads();

    for (int offset = blockDim.x / 2; offset > 0; offset /= 2) {
        if (tid < offset) {
            if (minrange[tid + offset] < minrange[tid]) {
                minrange[tid] = minrange[tid + offset];
            }
            if (maxrange[tid + offset] > maxrange[tid]) {
                maxrange[tid] = maxrange[tid + offset];
            }
        }
        __syncthreads();
    }

    if (tid == 0) {
        outmin[blockIdx.x] = minrange[0];
        outmax[blockIdx.x] = maxrange[0];
    }
}

// ===============================================
// Histogram kernels (unchanged from your source)
// ===============================================
__global__ void histonaive(int* input, int* gbin, int n, int binsize, int maxval, int minval) {
    int gid = threadIdx.x + blockDim.x * blockIdx.x;
    int range = maxval - minval + 1;
    int binwidth = range / binsize;
    if (binwidth < 1) binwidth = 1;

    if (gid < n) {
        int binindex = (input[gid] - minval) / binwidth;
        if (binindex >= binsize) binindex = binsize - 1;
        atomicAdd(&gbin[binindex], 1);
    }
}

__global__ void histosharedmemory(int* input, int* gbin, int n, int binsize, int maxval, int minval) {
    extern __shared__ int smbin[];
    int gid = threadIdx.x + blockDim.x * blockIdx.x;
    int range = maxval - minval + 1;
    int binwidth = range / binsize;
    if (binwidth < 1) binwidth = 1;

    for (int i = threadIdx.x; i < binsize; i += blockDim.x) {
        smbin[i] = 0;
    }
    __syncthreads();

    if (gid < n) {
        int binindex = (input[gid] - minval) / binwidth;
        if (binindex >= binsize) binindex = binsize - 1;
        atomicAdd(&smbin[binindex], 1);
    }
    __syncthreads();

    for (int i = threadIdx.x; i < binsize; i += blockDim.x) {
        atomicAdd(&gbin[i], smbin[i]);
    }
}

// ===============================================
// Helpers
// ===============================================
const int THREADSPERBLOCK = 512;
const int BINSIZE = 128;

struct Result {
    string algo;
    string impl;
    int N;
    float ms;
    bool verified;
};

// Reduce per-block min/max arrays down to a single (min,max) pair on device.
void reduceMinMax(int* d_blockmin, int* d_blockmax, int blockspergrid,
                   int*& d_inmin, int*& d_inmax, int*& d_outmin, int*& d_outmax,
                   int& nmin, int& nmax) {
    CUDA_CHECK(cudaMemcpy(d_inmin, d_blockmin, blockspergrid * sizeof(int), cudaMemcpyDeviceToDevice));
    CUDA_CHECK(cudaMemcpy(d_inmax, d_blockmax, blockspergrid * sizeof(int), cudaMemcpyDeviceToDevice));
    int currentsize = blockspergrid;
    while (currentsize > 1) {
        int needed = (currentsize + THREADSPERBLOCK - 1) / THREADSPERBLOCK;
        globalrangereduce<<<needed, THREADSPERBLOCK, 2 * THREADSPERBLOCK * sizeof(int)>>>(
            d_inmin, d_inmax, d_outmin, d_outmax, currentsize);
        currentsize = needed;
        swap(d_inmin, d_outmin);
        swap(d_inmax, d_outmax);
    }
    CUDA_CHECK(cudaMemcpy(&nmin, d_inmin, sizeof(int), cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(&nmax, d_inmax, sizeof(int), cudaMemcpyDeviceToHost));
}

// ===============================================
// CPU reference
// ===============================================
void cpuHistogram(const vector<int>& in, vector<int>& bins, int binsize) {
    bins.assign(binsize, 0);
    int cpumin = INT_MAX, cpumax = INT_MIN;
    for (int v : in) {
        cpumin = min(cpumin, v);
        cpumax = max(cpumax, v);
    }
    int range = cpumax - cpumin + 1;
    int binwidth = max(1, range / binsize);
    for (int v : in) {
        int idx = (v - cpumin) / binwidth;
        if (idx >= binsize) idx = binsize - 1;
        bins[idx]++;
    }
}

bool verify(const vector<int>& a, const vector<int>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); i++)
        if (a[i] != b[i]) return false;
    return true;
}

// ===============================================
// Benchmark harness (one pipeline per call)
// ===============================================
Result benchPipeline(const string& implName, int variant, // 0=naive,1=SM,2=warp
                      const vector<int>& h_in, const vector<int>& h_ref) {
    int n = (int)h_in.size();
    int blockspergrid = (n + THREADSPERBLOCK - 1) / THREADSPERBLOCK;

    int *d_data, *d_blockmin, *d_blockmax, *d_gbin;
    CUDA_CHECK(cudaMalloc(&d_data, n * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_blockmin, blockspergrid * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_blockmax, blockspergrid * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_gbin, BINSIZE * sizeof(int)));

    int *d_inmin, *d_inmax, *d_outmin, *d_outmax;
    CUDA_CHECK(cudaMalloc(&d_inmin, blockspergrid * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_inmax, blockspergrid * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_outmin, blockspergrid * sizeof(int)));
    CUDA_CHECK(cudaMalloc(&d_outmax, blockspergrid * sizeof(int)));

    CUDA_CHECK(cudaMemcpy(d_data, h_in.data(), n * sizeof(int), cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemset(d_gbin, 0, BINSIZE * sizeof(int)));

    cudaEvent_t start, stop;
    cudaEventCreate(&start); cudaEventCreate(&stop);
    cudaDeviceSynchronize();
    cudaEventRecord(start);

    if (variant == 0) {
        rangenaive<<<blockspergrid, THREADSPERBLOCK>>>(d_data, d_blockmin, d_blockmax, n);
    } else if (variant == 1) {
        rangesharedmemory<<<blockspergrid, THREADSPERBLOCK, 2 * THREADSPERBLOCK * sizeof(int)>>>(
            d_data, d_blockmin, d_blockmax, n);
    } else {
        int warpsperblock = THREADSPERBLOCK / 32;
        int warpsmbytes = 2 * warpsperblock * sizeof(int);
        rangewarpoptimized<<<blockspergrid, THREADSPERBLOCK, warpsmbytes>>>(d_data, d_blockmin, d_blockmax, n);
    }

    int nmin, nmax;
    reduceMinMax(d_blockmin, d_blockmax, blockspergrid, d_inmin, d_inmax, d_outmin, d_outmax, nmin, nmax);

    if (variant == 0) {
        histonaive<<<blockspergrid, THREADSPERBLOCK>>>(d_data, d_gbin, n, BINSIZE, nmax, nmin);
    } else {
        // SM and warp pipelines both use the shared-memory private-histogram kernel
        histosharedmemory<<<blockspergrid, THREADSPERBLOCK, BINSIZE * sizeof(int)>>>(d_data, d_gbin, n, BINSIZE, nmax, nmin);
    }

    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    float ms = 0;
    cudaEventElapsedTime(&ms, start, stop);

    vector<int> h_bin(BINSIZE);
    CUDA_CHECK(cudaMemcpy(h_bin.data(), d_gbin, BINSIZE * sizeof(int), cudaMemcpyDeviceToHost));
    bool ok = verify(h_bin, h_ref);

    cudaFree(d_data); cudaFree(d_blockmin); cudaFree(d_blockmax); cudaFree(d_gbin);
    cudaFree(d_inmin); cudaFree(d_inmax); cudaFree(d_outmin); cudaFree(d_outmax);
    cudaEventDestroy(start); cudaEventDestroy(stop);

    return {"Histogram", implName, n, ms, ok};
}

// ===============================================
// Output helpers
// ===============================================
string getGPUName() {
    cudaDeviceProp prop;
    int dev = 0;
    cudaGetDevice(&dev);
    cudaGetDeviceProperties(&prop, dev);
    return string(prop.name);
}

string timestamp() {
    time_t t = time(nullptr);
    tm* lt = localtime(&t);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d_%H%M%S", lt);
    return string(buf);
}

void writeCSV(const vector<Result>& results, const string& gpuName, const string& path) {
    ofstream f(path);
    f << "gpu,algorithm,implementation,N,time_ms,verified\n";
    for (auto& r : results) {
        f << gpuName << "," << r.algo << "," << r.impl << "," << r.N << ","
          << fixed << setprecision(6) << r.ms << "," << (r.verified ? "PASS" : "FAIL") << "\n";
    }
    f.close();
}

void writeMarkdown(const vector<Result>& results, const string& gpuName, const string& path) {
    ofstream f(path);
    f << "# Histogram Pipeline Benchmark\n\n";
    f << "GPU: **" << gpuName << "**\n\n";
    f << "Bins: " << BINSIZE << " | Threads/block: " << THREADSPERBLOCK << "\n\n";
    f << "| Algorithm | Implementation | N | Time (ms) | Verified |\n";
    f << "|---|---|---|---|---|\n";
    for (auto& r : results) {
        f << "| " << r.algo << " | " << r.impl << " | " << r.N << " | "
          << fixed << setprecision(4) << r.ms << " | " << (r.verified ? "PASS" : "FAIL") << " |\n";
    }
    f << "\n## Speedup vs Naive\n\n";
    f << "| N | SM Speedup | Warp Speedup |\n";
    f << "|---|---|---|\n";
    for (size_t i = 0; i + 2 < results.size(); i += 3) {
        float naiveMs = results[i].ms;
        float smMs = results[i + 1].ms;
        float warpMs = results[i + 2].ms;
        f << "| " << results[i].N << " | " << fixed << setprecision(2)
          << (naiveMs / smMs) << "x | " << (naiveMs / warpMs) << "x |\n";
    }
    f.close();
}

void printTable(const vector<Result>& results) {
    cout << "\n";
    cout << left
         << setw(16) << "Algorithm"
         << setw(28) << "Implementation"
         << setw(12) << "N"
         << setw(16) << "Time (ms)"
         << setw(12) << "Verified" << "\n";
    cout << string(84, '-') << "\n";
    for (auto& r : results) {
        cout << left
             << setw(16) << r.algo
             << setw(28) << r.impl
             << setw(12) << r.N
             << setw(16) << fixed << setprecision(4) << r.ms
             << setw(12) << (r.verified ? "PASS" : "FAIL") << "\n";
    }
    cout << string(84, '-') << "\n";

    cout << "\nSpeedup vs Naive:\n";
    for (size_t i = 0; i + 2 < results.size(); i += 3) {
        float naiveMs = results[i].ms;
        float smMs = results[i + 1].ms;
        float warpMs = results[i + 2].ms;
        cout << "  N=" << results[i].N
             << "  SM: " << fixed << setprecision(2) << (naiveMs / smMs) << "x"
             << "   Warp: " << (naiveMs / warpMs) << "x\n";
    }
}

vector<int> parseSizes(int argc, char** argv) {
    vector<int> sizes = {1 << 15, 1 << 18, 1 << 20, 1 << 22};
    if (argc > 1) {
        sizes.clear();
        stringstream ss(argv[1]);
        string tok;
        while (getline(ss, tok, ',')) {
            if (!tok.empty()) sizes.push_back(atoi(tok.c_str()));
        }
    }
    return sizes;
}

int main(int argc, char** argv) {
    vector<int> sizes = parseSizes(argc, argv);
    vector<Result> results;

    string gpuName = getGPUName();
    cout << "GPU: " << gpuName << "\n\n";

    srand(42);
    for (int n : sizes) {
        vector<int> h_in(n);
        for (int i = 0; i < n; i++) h_in[i] = rand() % 500;

        vector<int> h_ref;
        cpuHistogram(h_in, h_ref, BINSIZE);

        results.push_back(benchPipeline("Naive (global mem)", 0, h_in, h_ref));
        results.push_back(benchPipeline("SM-Optimized (shared mem)", 1, h_in, h_ref));
        results.push_back(benchPipeline("Warp-Optimized (shfl)", 2, h_in, h_ref));

        cout << "Completed N=" << n << "\n";
    }

    printTable(results);

    system("mkdir -p results");
    string ts = timestamp();
    string csvPath = "results/run_histogram_" + ts + ".csv";
    string mdPath = "results/run_histogram_" + ts + ".md";
    writeCSV(results, gpuName, csvPath);
    writeMarkdown(results, gpuName, mdPath);
    cout << "\nSaved: " << csvPath << "\nSaved: " << mdPath << "\n";

    return 0;
}
